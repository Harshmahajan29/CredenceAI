# Verification Agent

An evidence-driven, zero-trust claim verification agent. Receives a claim
JSON, fans out to four parallel investigative pipelines, aggregates evidence
via Bayesian log-odds fusion, and returns a single explainable verdict.

```
claim JSON  ──►  [ multi_search  ]  ─┐
                 [ social_sentiment] ─┤──► aggregator ──► verdict JSON
                 [ model_validation] ─┤    (log-odds)
                 [ source_behavior ] ─┘
```

## Quick start

```bash
cp .env.example .env          # configure API keys (see docs/PLACEHOLDERS.md)
pip install -r requirements.txt
playwright install chromium   # for crawl4ai page fetching

python agent.py --claim claim_sample.json
```

## Project layout

```
verification_agent/
├── agent.py                   # Main orchestrator
├── claim_sample.json          # Example input
├── requirements.txt
├── pytest.ini
├── .env.example
│
├── config/
│   └── settings.py            # All configuration + PLACEHOLDER markers
│
├── pipelines/
│   ├── multi_search.py        # Pipeline 1: zero-trust web search + clustering
│   ├── social_sentiment.py    # Pipeline 2: Reddit + Twitter + sentiment
│   ├── model_validation.py    # Pipeline 3: fact-check APIs + NewsAPI + Finnhub
│   └── source_behavior.py     # Pipeline 4: DB source history + spaced repetition
│
├── scoring/
│   ├── aggregator.py          # Bayesian log-odds fusion → P_true + CI
│   └── classifier.py          # credibilityScore + bucket + actions
│
├── utils/
│   ├── schema.py              # Pydantic input/output models
│   ├── embeddings.py          # Embedding backend switcher
│   ├── db.py                  # SQLAlchemy source history helpers
│   └── logger.py              # Structured logger
│
├── tests/
│   ├── test_aggregator.py     # 15 unit tests for scoring math
│   ├── test_classifier.py     # 10 unit tests for classification logic
│   ├── test_schema.py         # 14 unit tests for I/O validation
│   └── test_agent_integration.py  # 13 end-to-end tests (mocked pipelines)
│
└── docs/
    └── PLACEHOLDERS.md        # ← START HERE — full configuration guide
```

## Output schema

```json
{
  "claim_id":            "string",
  "p_true":              0.72,
  "credibility_score":   72,
  "bucket":              "high",
  "confidence_interval": [0.60, 0.82],
  "explanation":         "Three independent clusters support the claim...",
  "evidence_units":      [...],
  "risk_proxy":          0.18,
  "actions":             [{"type": "log_only", "reason": "..."}],
  "meta": {
    "searches_performed": 4,
    "retries":            1,
    "elapsed_ms":         1840,
    "plan_trace":         [...],
    "zero_trust_mode":    true
  },
  "zero_trust_mode": true
}
```

## Credibility buckets

| Score | Bucket | Typical actions |
|---|---|---|
| 0–39 | `low` | Block automation + human review |
| 40–65 | `moderate` | Human review |
| 66–85 | `high` | Log only (unless financial/viral) |
| 86–100 | `critical` | Log only |

## Running tests

```bash
pytest -v                                  # all 52 tests
pytest tests/test_aggregator.py -v        # scoring math only (no network)
pytest tests/test_agent_integration.py -v # end-to-end with mocked pipelines
```

## Configuration

See **`docs/PLACEHOLDERS.md`** for a complete guide to every value that must
be set before production use.
