"""
verification_agent/scoring/classifier.py
==========================================
Maps P_true + context signals → credibilityScore, bucket, and actions.

Buckets
-------
  low      : credibilityScore  0–39   → likely misinformation
  moderate : credibilityScore 40–65   → uncertain, needs review
  high     : credibilityScore 66–85   → probably credible
  critical : credibilityScore 86–100  → strong evidence of truth

Action types (ordered by severity)
-----------------------------------
  log_only             — record verdict, no further action
  recommend_monitor    — flag for periodic re-check
  recommend_human_review — escalate to a human analyst
  block_automated_action — stop any downstream automation
"""

from __future__ import annotations


def classify_score(
    p_true:              float,
    ci:                  list[float],
    entities:            list[str],
    market_signals:      dict,
    social_signals:      dict,
    independent_clusters: int,
) -> tuple[int, str, list[dict]]:
    """
    Returns (credibility_score, bucket, actions).
    """
    score  = round(p_true * 100)
    bucket = _to_bucket(score)
    ci_width = ci[1] - ci[0]

    actions: list[dict] = []

    # ── Low credibility ───────────────────────────────────────────────────────
    if bucket == "low":
        actions.append({
            "type":   "recommend_human_review",
            "reason": "credibility_low",
            "detail": f"credibilityScore={score}, P_true={p_true:.2f}",
        })
        actions.append({
            "type":   "block_automated_action",
            "reason": "claim_likely_false",
        })

    # ── Moderate: wide CI or few independent clusters ─────────────────────────
    elif bucket == "moderate" or ci_width > 0.30 or independent_clusters < 3:
        actions.append({
            "type":   "recommend_human_review",
            "reason": "insufficient_evidence" if independent_clusters < 3 else "high_uncertainty",
            "detail": f"independent_clusters={independent_clusters}, CI_width={ci_width:.2f}",
        })

    # ── High velocity social signal + uncertain claim ─────────────────────────
    prop_velocity = social_signals.get("propagation_velocity", 0.0)
    bot_score     = social_signals.get("bot_score", 0.0)
    if prop_velocity > 0.6 and independent_clusters < 3:
        actions.append({
            "type":   "recommend_human_review",
            "reason": "viral_low_evidence",
            "detail": f"propagation_velocity={prop_velocity:.2f}, independent_clusters={independent_clusters}",
        })
    if bot_score > 0.5:
        actions.append({
            "type":   "recommend_human_review",
            "reason": "bot_amplification_detected",
            "detail": f"bot_score={bot_score:.2f}",
        })

    # ── Financial risk ────────────────────────────────────────────────────────
    risk_proxy      = (market_signals or {}).get("risk_proxy")
    price_change    = abs((market_signals or {}).get("price_change_pct", 0.0))
    if entities and (risk_proxy is not None and risk_proxy > 0.15 or price_change > 5):
        actions.append({
            "type":   "recommend_human_review",
            "reason": "financial_exposure_high",
            "detail": f"risk_proxy={risk_proxy}, price_change_pct={price_change:.2f}",
        })
        actions.append({
            "type":   "block_automated_action",
            "reason": "market_moving_risk",
        })

    # ── Default: just log ─────────────────────────────────────────────────────
    if not actions:
        actions.append({
            "type":   "log_only",
            "reason": "claim_verified_within_thresholds",
        })

    # Deduplicate actions
    seen = set()
    deduped_actions = []
    for a in actions:
        key = a["type"] + a.get("reason", "")
        if key not in seen:
            seen.add(key)
            deduped_actions.append(a)

    return score, bucket, deduped_actions


def _to_bucket(score: int) -> str:
    if score < 40:
        return "low"
    elif score <= 65:
        return "moderate"
    elif score <= 85:
        return "high"
    return "critical"
