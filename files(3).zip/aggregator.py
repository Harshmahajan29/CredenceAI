"""
verification_agent/scoring/aggregator.py
==========================================
Bayesian log-odds aggregation of all evidence units into a single P_true
with confidence interval and plain-English explanation.

Math
----
  log_odds(P) = log(P / (1 - P))
  For each independent unit i with weight w_i and LR_i:
    log_odds_posterior += w_i * log(LR_i)
  P_true = sigmoid(log_odds_posterior)
  CI via Gaussian approximation on log-odds space.
"""

from __future__ import annotations
import math
from collections import Counter


def aggregate_evidence(
    units:    list[dict],
    prior:    float = 0.5,
) -> dict:
    """
    Parameters
    ----------
    units   : list of evidence unit dicts (must have lr, independence_weight, type, cluster_id)
    prior   : P(claim is true) before seeing any evidence

    Returns
    -------
    {
      "p_true":             float,
      "confidence_interval": [float, float],
      "explanation":        str,
      "log_odds_trace":     list[dict],
    }
    """
    # Collapse units to one per cluster (keep max |LR| per cluster)
    deduplicated = _deduplicate_by_cluster(units)

    # Start from prior
    prior_clamped = max(1e-6, min(1 - 1e-6, prior))
    log_odds = _to_log_odds(prior_clamped)
    trace    = [{"step": "prior", "log_odds": round(log_odds, 4), "p": round(prior, 4)}]

    variances = []  # for CI computation

    for unit in deduplicated:
        lr  = float(unit.get("lr", 1.0))
        w   = float(unit.get("independence_weight", 1.0))
        lr  = max(1e-4, lr)          # guard log(0)
        adj = w * math.log(lr)
        log_odds += adj
        # Variance contribution (approximation: treat log LR as Gaussian with σ=|adj|*0.3)
        variances.append((abs(adj) * 0.3) ** 2)
        trace.append({
            "step":          f"unit_{unit.get('id','?')[:8]}",
            "domain":        unit.get("domain", ""),
            "type":          unit.get("type", ""),
            "lr":            round(lr, 4),
            "weight":        round(w, 4),
            "adj_log_odds":  round(adj, 4),
            "cumulative_log_odds": round(log_odds, 4),
        })

    p_true = _from_log_odds(log_odds)

    # CI: Gaussian approx on log-odds
    total_var = sum(variances) if variances else 0.25
    std       = math.sqrt(total_var)
    lo_lower  = log_odds - 1.96 * std
    lo_upper  = log_odds + 1.96 * std
    ci        = [
        round(_from_log_odds(lo_lower), 4),
        round(_from_log_odds(lo_upper), 4),
    ]

    explanation = _build_explanation(p_true, ci, deduplicated, units)

    return {
        "p_true":              round(p_true, 4),
        "confidence_interval": ci,
        "explanation":         explanation,
        "log_odds_trace":      trace,
    }


# ── De-duplication ────────────────────────────────────────────────────────────

def _deduplicate_by_cluster(units: list[dict]) -> list[dict]:
    """
    For each cluster, keep only the most informative unit
    (highest absolute LR deviation from 1.0).
    Independence weights are already pre-adjusted by the pipelines.
    """
    clusters: dict[str, dict] = {}
    for u in units:
        cid  = u.get("cluster_id") or u.get("id", "")
        lr   = float(u.get("lr", 1.0))
        best = clusters.get(cid)
        if best is None or abs(lr - 1.0) > abs(float(best.get("lr", 1.0)) - 1.0):
            clusters[cid] = u
    return list(clusters.values())


# ── Math helpers ──────────────────────────────────────────────────────────────

def _to_log_odds(p: float) -> float:
    p = max(1e-9, min(1 - 1e-9, p))
    return math.log(p / (1 - p))


def _from_log_odds(lo: float) -> float:
    # Clamp to avoid overflow
    lo = max(-500, min(500, lo))
    return 1.0 / (1.0 + math.exp(-lo))


# ── Explanation builder ───────────────────────────────────────────────────────

def _build_explanation(
    p_true: float,
    ci: list[float],
    deduped: list[dict],
    all_units: list[dict],
) -> str:
    n_total    = len(all_units)
    n_unique   = len(deduped)
    n_support  = sum(1 for u in deduped if u.get("type") == "support")
    n_contra   = sum(1 for u in deduped if u.get("type") == "contradict")
    n_clusters = len({u.get("cluster_id") for u in deduped if u.get("cluster_id")})

    provenances = Counter(u.get("provenance", "unknown") for u in all_units)
    prov_str    = ", ".join(f"{k}={v}" for k, v in provenances.most_common(4))

    ci_width = ci[1] - ci[0]
    confidence_label = (
        "high confidence" if ci_width <= 0.20 else
        "moderate confidence" if ci_width <= 0.35 else
        "low confidence"
    )

    verdict = (
        "strongly supported" if p_true >= 0.80 else
        "likely true"        if p_true >= 0.65 else
        "uncertain"          if p_true >= 0.45 else
        "likely false"       if p_true >= 0.25 else
        "strongly contradicted"
    )

    return (
        f"Claim is {verdict} (P_true={p_true:.2f}, {confidence_label}, "
        f"CI=[{ci[0]:.2f},{ci[1]:.2f}]). "
        f"Processed {n_total} raw evidence units collapsed to {n_unique} independent units "
        f"across {n_clusters} clusters. "
        f"{n_support} unit(s) support the claim; {n_contra} contradict it. "
        f"Evidence sources: {prov_str}."
    )
