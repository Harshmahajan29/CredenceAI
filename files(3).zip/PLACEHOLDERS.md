# PLACEHOLDERS.md — Complete guide to every `# ← PLACEHOLDER` in the codebase

This document lists every value you must configure before running the agent
in production. Values are grouped by urgency. Each entry shows **what to
change**, **where to change it**, and **how to get the credential**.

---

## Tier 1 — Required to run at all

These values must be set before the agent can process any claim.

---

### 1. `prior_p_true`
| Field | Value |
|---|---|
| **File** | `config/settings.py` |
| **Setting** | `prior_p_true: float = 0.5` |
| **What it is** | The Bayesian prior probability that a claim is true before any evidence is seen. `0.5` = maximum uncertainty (uninformative). |
| **How to fix** | Measure your scraper's baseline accuracy on a labelled holdout set. If 60% of your scraped claims turn out to be true, set `prior_p_true = 0.6`. Run at `0.5` until you have ground-truth data. |

---

### 2. `EVIDENCE_DB_DSN`
| Field | Value |
|---|---|
| **File** | `config/settings.py`, `.env` |
| **Default** | `sqlite:///./evidence.db` |
| **What it is** | SQLAlchemy connection string for the source-history database. SQLite is fine for development and single-machine deployments. |
| **How to fix (dev)** | Leave as-is. A file `evidence.db` will be auto-created on first run. |
| **How to fix (prod)** | Provision a PostgreSQL instance. Set `EVIDENCE_DB_DSN=postgresql+psycopg2://user:pass@host:5432/dbname` in your `.env`. Install `psycopg2-binary` (`pip install psycopg2-binary`). |

---

## Tier 2 — Required for full pipeline coverage

Omitting any of these causes that pipeline to be silently skipped.
The agent degrades gracefully but confidence intervals will be wider.

---

### 3. Search backend

**Default (zero-cost):** DuckDuckGo — no key needed, works out of the box.

**Upgrade option A — Serper.dev (Google results)**
| Field | Value |
|---|---|
| **File** | `.env` → `SERPER_API_KEY` |
| **Setting** | `config/settings.py` → `search_backend = "serper"` |
| **Get key** | https://serper.dev → sign up → API Keys → copy key |
| **Cost** | ~$0.001 per query; 2 500 free queries on signup |

**Upgrade option B — Google Custom Search Engine**
| Field | Value |
|---|---|
| **Files** | `.env` → `GOOGLE_CSE_ID`, `GOOGLE_CSE_API_KEY` |
| **Setting** | `config/settings.py` → `search_backend = "google_cse"` |
| **Get key** | https://programmablesearchengine.google.com → create engine → get CSE ID; https://console.cloud.google.com → Custom Search API → enable → credentials → API key |

---

### 4. `FACTCHECK_API_KEY` — Google Fact Check Tools API
| Field | Value |
|---|---|
| **File** | `.env` → `FACTCHECK_API_KEY` |
| **Get key** | https://console.cloud.google.com → enable "Fact Check Tools API" → Credentials → Create API Key |
| **Cost** | Free (1 000 requests/day) |
| **What happens without it** | `model_validation` pipeline skips Google fact-check lookups; LR from this source = 0 |

---

### 5. `CLAIMBUSTER_API_KEY` — ClaimBuster check-worthiness scorer
| Field | Value |
|---|---|
| **File** | `.env` → `CLAIMBUSTER_API_KEY` |
| **Get key** | https://idir.uta.edu/claimbuster/ → "Get API Key" → register → email confirmation |
| **Cost** | Free for academic/research use |
| **What happens without it** | ClaimBuster scoring step is skipped |

---

### 6. `NEWSAPI_KEY` — NewsAPI.org
| Field | Value |
|---|---|
| **File** | `.env` → `NEWSAPI_KEY` |
| **Get key** | https://newsapi.org/register → free developer account |
| **Cost** | Free for dev (100 req/day, no commercial use). Business plan from $449/mo. |
| **What happens without it** | NewsAPI coverage check is skipped; 1–2 fewer evidence units per claim |
| **Production note** | Free tier forbids commercial use. For production, use the paid tier or replace with a self-hosted news feed (RSS → database). |

---

### 7. `REDDIT_CLIENT_ID` + `REDDIT_CLIENT_SECRET` — Reddit API
| Field | Value |
|---|---|
| **File** | `.env` → `REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET` |
| **Get key** | Log into Reddit → https://www.reddit.com/prefs/apps → "Create App" → type: "script" → set redirect URI to `http://localhost:8080` → copy `client_id` (under app name) and `secret` |
| **Cost** | Free (100 req/10 min) |
| **What happens without it** | Falls back to crawl4ai scraping `old.reddit.com` (slower, less reliable) |

---

### 8. `TWITTER_BEARER_TOKEN` — X (Twitter) API v2
| Field | Value |
|---|---|
| **File** | `.env` → `TWITTER_BEARER_TOKEN` |
| **Get key** | https://developer.twitter.com → "Create Project" → "Create App" → "Keys and Tokens" → "Bearer Token" |
| **Cost** | Free tier: 500k tweet reads/month. Basic: $100/mo for higher limits. |
| **What happens without it** | Twitter social pipeline is entirely skipped |
| **Note** | The API now requires a paid plan for most search endpoints. If cost is a concern, set `TWITTER_BEARER_TOKEN=skip` and the pipeline will no-op cleanly. |

---

### 9. `FINNHUB_API_KEY` — Market data
| Field | Value |
|---|---|
| **File** | `.env` → `FINNHUB_API_KEY` |
| **Get key** | https://finnhub.io/register → free account → Dashboard → API Key |
| **Cost** | Free tier: 60 req/min, real-time US data |
| **What happens without it** | `risk_proxy` will be `null` in output; no market anomaly evidence units |

---

## Tier 3 — Embedding and sentiment model configuration

---

### 10. Embedding backend
| Field | Value |
|---|---|
| **File** | `config/settings.py` → `embedding_backend` |
| **Default** | `"sentence_transformers"` with model `"all-MiniLM-L6-v2"` |

**Option A — Sentence Transformers (default, free, local)**
- No API key needed.
- Install: `pip install sentence-transformers`
- Model downloads automatically on first run (~90 MB).
- Change `embedding_model` to `"all-mpnet-base-v2"` for better quality at the cost of speed.

**Option B — OpenAI embeddings (best quality)**
- Set `embedding_backend = "openai"` and `OPENAI_API_KEY` in `.env`.
- Model: `"text-embedding-3-small"` (default) or `"text-embedding-3-large"`.
- Cost: ~$0.00002 / 1K tokens.

---

### 11. Sentiment model
| Field | Value |
|---|---|
| **File** | `config/settings.py` → `sentiment_model` |
| **Default** | `"ProsusAI/finbert"` (financial sentiment) |

- For financial claims: keep `"ProsusAI/finbert"`.
- For general news: change to `"distilbert-base-uncased-finetuned-sst-2-english"` (lighter, faster).
- Requires: `pip install transformers torch` (CPU-only torch is fine for dev).
- Falls back automatically to VADER if transformers is not installed.

---

## Tier 4 — Scoring calibration (tune after you have labelled data)

These are the values that most affect output quality. They should be tuned
empirically on a labelled holdout set of 200+ claims.

---

### 12. `lr_mapping` — Semantic similarity → likelihood ratio table
| Field | Value |
|---|---|
| **File** | `config/settings.py` → `lr_mapping` |

```python
lr_mapping = {
    "high":   3.0,    # similarity ≥ 0.85 → LR = 3.0
    "medium": 1.8,    # similarity 0.65–0.85
    "low":    1.1,    # similarity 0.40–0.65
    "noise":  0.9,    # similarity < 0.40
}
```

**How to calibrate:**
1. Run the agent on ~200 labelled claims (ground truth: true/false).
2. Record the similarity scores and whether each claim was actually true.
3. For each bucket, compute `LR = P(sim in bucket | true) / P(sim in bucket | false)`.
4. Replace the default values with your measured LRs.

A well-calibrated LR table will tighten confidence intervals significantly.

---

### 13. `_resolve_ticker` — Entity → stock ticker mapping
| Field | Value |
|---|---|
| **File** | `pipelines/model_validation.py` → `_resolve_ticker()` |

The current implementation is a hardcoded dict of 8 companies. For production:
- **Option A:** Use Finnhub's `/search` endpoint: `GET /search?q={entity_name}&token={key}` returns ticker symbols.
- **Option B:** Use a dedicated NER model (e.g. spaCy + FinBERT NER) to extract company names and resolve them via a ticker database.
- **Option C:** Maintain your own `entity → ticker` lookup table in your database.

---

### 14. Finnhub date range (hardcoded)
| Field | Value |
|---|---|
| **File** | `pipelines/model_validation.py` → `_query_finnhub()` |
| **Lines** | `"from": "2026-04-01"` and `"to": "2026-04-18"` |

These are hardcoded. Fix by deriving from `claim.timestamp`:

```python
from datetime import timedelta
claim_date = claim.timestamp.date()
date_from  = (claim_date - timedelta(days=7)).isoformat()
date_to    = claim_date.isoformat()
```

---

### 15. Bot detection classifier
| Field | Value |
|---|---|
| **File** | `pipelines/social_sentiment.py` → `_heuristic_bot_score()` |

The current implementation uses 3 simple heuristics. For production:
- Train a binary classifier on labelled bot/human posts (features: account age, post velocity, karma distribution, text entropy).
- Or use the [Botometer API](https://botometer.osome.iu.edu/) for Twitter accounts.
- Drop in by replacing the function body; keep the `0.0–1.0` return range.

---

### 16. `_OWNERSHIP_CLUSTERS` — Media ownership map
| Field | Value |
|---|---|
| **File** | `pipelines/source_behavior.py` → `_OWNERSHIP_CLUSTERS` |

The current dict covers ~8 publishers. For production:
- Expand manually from the [Media Ownership Monitor](https://www.mom-gmr.org/) dataset.
- Or integrate a WHOIS/news-provenance API.
- This dict is purely for independence weighting; wrong entries reduce accuracy but don't crash the system.

---

## Quick start — minimum viable configuration

To get the agent running with no paid APIs in under 5 minutes:

```bash
# 1. Copy environment file
cp .env.example .env

# 2. All defaults use DuckDuckGo + local SentenceTransformers + SQLite.
#    No keys needed for a basic run.

# 3. Install dependencies
pip install -r requirements.txt
playwright install chromium   # for crawl4ai

# 4. Run on the sample claim
python agent.py --claim claim_sample.json
```

The agent will run with:
- ✅ DuckDuckGo search (free)
- ✅ Local sentence-transformers embeddings (free)
- ✅ VADER sentiment (free)
- ✅ SQLite evidence DB (auto-created)
- ⚠️ Social pipeline → Reddit crawl4ai fallback (no PRAW key)
- ⚠️ Fact-check, NewsAPI, Finnhub → skipped (no keys)
- ⚠️ Twitter → skipped (no bearer token)

Expected output: valid JSON verdict with `confidence_interval` width ~0.35–0.50
(wide, because fewer evidence sources). Add API keys incrementally to tighten CIs.

---

## Running the tests

```bash
# Pure unit tests (no network, no API keys needed)
pytest tests/test_aggregator.py tests/test_classifier.py tests/test_schema.py -v

# Integration test (mocked pipelines, no network)
pytest tests/test_agent_integration.py -v

# All tests
pytest -v
```
